// frontend/src/components/StudentDashboard/VotePoll.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function VotePoll({ classCode }) {
  const [polls, setPolls] = useState([]);
  const [selectedPollId, setSelectedPollId] = useState('');
  const [selectedOptionIndex, setSelectedOptionIndex] = useState(null);

  useEffect(() => {
    const fetchPolls = async () => {
      try {
        const response = await axios.get(`/api/polls/${classCode}`);
        setPolls(response.data);
      } catch (error) {
        console.error('Error fetching polls:', error);
      }
    };

    fetchPolls();
  }, [classCode]);

  const handleVote = async () => {
    if (selectedOptionIndex === null) {
      alert('Please select an option.');
      return;
    }

    try {
      await axios.post('/api/polls/vote', { pollId: selectedPollId, optionIndex: selectedOptionIndex });
      alert('Vote submitted successfully!');
    } catch (error) {
      console.error('Error submitting vote:', error);
      alert('Error submitting vote');
    }
  };

  return (
    <div>
      <h2>Vote on Poll</h2>
      <div>
        {polls.map((poll) => (
          <div key={poll._id}>
            <h3>{poll.question}</h3>
            {poll.options.map((option, index) => (
              <div key={index}>
                <input
                  type="radio"
                  name="pollOption"
                  value={index}
                  onChange={() => setSelectedOptionIndex(index)}
                />
                <label>{option.option}</label>
              </div>
            ))}
            <button onClick={() => setSelectedPollId(poll._id)}>Select Poll</button>
          </div>
        ))}
      </div>
      <button onClick={handleVote}>Submit Vote</button>
    </div>
  );
}

export default VotePoll;
